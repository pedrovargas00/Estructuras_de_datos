
public class ClaveDuplicadaException extends Exception{
    
    public ClaveDuplicadaException(){
        super("Valor duplicado");
    }
    
}
