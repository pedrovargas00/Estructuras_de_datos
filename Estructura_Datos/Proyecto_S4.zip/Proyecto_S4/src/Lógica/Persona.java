package Lógica;

import Controlador.Controlador;

public class Persona {
        
    //Atributos
    private Persona padre;
    private Persona madre;
    private String nombre;
    private int edad;
    private char sexo;
    private float peso;
    private float estatura;
    private String nacionalidad;
    private Controlador controlador;
    
    public Persona(){
       this.nombre = " ";
       this.edad = 0;
       this.sexo = ' ';
       this.peso = 0;
       this.estatura = 0 ;
       this.nacionalidad = "";
    }

    public void setControlador(Controlador controlador){
        this.controlador = controlador;
    }
    
    public Persona getPadre() {
        return padre;
    }

    public void setPadre(Persona padre) {
        this.padre = padre;
    }

    public Persona getMadre() {
        return madre;
    }

    public void setMadre(Persona madre) {
        this.madre = madre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public float getEstatura() {
        return estatura;
    }

    public void setEstatura(float estatura) {
        this.estatura = estatura;
    }

    public String getNacionalidad() {
        return nacionalidad;
    }

    public void setNacionalidad(String nacionalidad) {
        this.nacionalidad = nacionalidad;
    }
    
}
