/*
Elaboró:
Ramos López Lizbeth
Vargas Arenas Pedro
*/
import java.util.*;
public class TestListaLigada {
    
    public static void main (String[]args){
        Scanner in = new Scanner(System.in);
        ListaLigada ll = new ListaLigada();
        int dato = 0;
        
        System.out.println("Insertando Ordenado");
        for(int i = 0; i < 5; i++){
            dato = (int)(Math.random()*100)+1;
            ll.insertarOrdenado(dato);
            System.out.println(ll.mostrar());
        }
    
        System.out.println("Inviertiendo la lista");
        ll.invertir();
        System.out.println(ll.mostrar());

        System.out.println("Pasando Mayor al final");
        ll.moverMayor();
        System.out.println(ll.mostrar());

        System.out.println("Eliminando último dato");
        ll.eliminarAlFinal ();
        System.out.println(ll.mostrar());
        
        
        System.out.println("Ingrese el dato a eliminar: ");
        dato = in.nextInt();
        System.out.println("Eliminando nodo específico: " + dato);
        ll.eliminarDato(dato);
        System.out.println(ll.mostrar());
    }
}
