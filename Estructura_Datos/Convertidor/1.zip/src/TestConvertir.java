
import javax.swing.JFrame;


public class TestConvertir {
    
    public static void main(String []args){
        
        Convertidor miVista = new Convertidor();
        
        miVista.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        miVista.setVisible(true);
    }
}
