package Enfermedades;

public class Neural {
    
    private boolean temperatura;
    private boolean diabetes;
    
    public Neural(){}

    public boolean isTemperatura() {
        return temperatura;
    }

    public void setTemperatura(boolean temperatura) {
        this.temperatura = temperatura;
    }

    public boolean isDiabetes() {
        return diabetes;
    }

    public void setDiabetes(boolean diabetes) {
        this.diabetes = diabetes;
    }
    
    
}
