package Enfermedades;


public class Diabetes {
 
    private boolean padresHerencia;
    private boolean fatiga;
    
    public Diabetes(){}

    public boolean isPadresHerencia() {
        return padresHerencia;
    }

    public void setPadresHerencia(boolean padresHerencia) {
        this.padresHerencia = padresHerencia;
    }

    public boolean isFatiga() {
        return fatiga;
    }

    public void setFatiga(boolean fatiga) {
        this.fatiga = fatiga;
    }
    
    
}
