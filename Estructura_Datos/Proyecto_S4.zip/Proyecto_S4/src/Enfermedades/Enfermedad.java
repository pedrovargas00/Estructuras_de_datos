package Enfermedades;

public class Enfermedad {
    
    protected boolean obesidad;
    protected boolean hipertension;
    protected int edad;
    protected String ubicacionGeo;
    protected String medicamento;
    protected boolean sobrepeso;
    
    public Enfermedad(){
        
        obesidad = false;
        sobrepeso = false;
        edad = 0;
        ubicacionGeo = "";
        medicamento = "";
    }

    public boolean isObesidad() {
        return obesidad;
    }

    public void setObesidad(boolean obesidad) {
        this.obesidad = obesidad;
    }

    public boolean isHipertension() {
        return hipertension;
    }

    public void setHipertension(boolean hipertension) {
        this.hipertension = hipertension;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getUbicacionGeo() {
        return ubicacionGeo;
    }

    public void setUbicacionGeo(String ubicacionGeo) {
        this.ubicacionGeo = ubicacionGeo;
    }

    public String getMedicamento() {
        return medicamento;
    }

    public void setMedicamento(String medicamento) {
        this.medicamento = medicamento;
    }

    public boolean isSobrepeso() {
        return sobrepeso;
    }

    public void setSobrepeso(boolean sobrepeso) {
        this.sobrepeso = sobrepeso;
    }
    
    private float IMC(float peso, float estatura){
    
        float imc = (float) (peso/Math.pow((double)estatura, 2));
        
        return imc;
        
    }
    
    public void rangoObesidad(float peso, float estatura){
        
        if(IMC(peso, estatura) < 18.5f){
            setObesidad(false);
            setSobrepeso(false);
        }else{
            if(IMC(peso, estatura) > 27.0f && IMC(peso, estatura) < 29.9f){
                setSobrepeso(true);
                setObesidad(false);
            }else{
                if(IMC(peso, estatura) > 30.0f && IMC(peso, estatura) < 49.9f){
                    setSobrepeso(true);
                    setObesidad(true);
                }
            }
        }
            
    }
    
    
}
